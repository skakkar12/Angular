﻿/// <reference path="../angular.js" />
var app;
(function () {
    app = angular.module("crudModule", []);
})();
